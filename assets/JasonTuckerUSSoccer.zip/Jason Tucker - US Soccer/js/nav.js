f:/* Jason Tucker CMSY 168 */


/* --------------- Nav bar ----------------- */

// Nav bar: Collapses top portion on scroll
$(window).scroll(function() {
    if ($(".divtop").offset().top > 400) {
        $(".divtop").addClass("minnavtop");
        $(".collapse").addClass("collapseon");
        $("#homelink").removeClass("collapseon");
    } else {
        $(".divtop").removeClass("minnavtop");
        $(".collapse").removeClass("collapseon");
        $("#homelink").addClass("collapseon");
    }
});

// Easing scroll: easein/out on link placeholder clicks
$(function() {
    $('a.scroll').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1000, 'easeInOutExpo');
        event.preventDefault();
    });
});

/*  ------------------- Contact Us form  -------------------------- */

// draggable wrapper/form
$(function() {
	$( "#formWrapper" ).draggable({
	});
});

// Make form visible on "contact us" button click
$( "#contactButton" ).click(function() {
  $("#formWrapper").removeClass("invisible");
});

// Make form invisible on "cancel" button click
$( "#cancelButton" ).click(function() {
  $("#formWrapper").addClass("invisible");
});

// Submit Thank you alert
function formSubmission(form) {
  alert("Thank you for your comment, " + document.getElementById("name").value + ".");
  return true;
}
