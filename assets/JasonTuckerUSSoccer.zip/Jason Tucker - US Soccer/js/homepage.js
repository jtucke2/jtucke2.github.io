/* Jason Tucker -- Allows for transparency in nav bar, must put transparent class in css*/

$(window).scroll(function() {
    if ($(".divtop").offset().top > 400) {
        $("#banwrapper").removeClass("transparent");
    } else {
        $("#banwrapper").addClass("transparent");
    }
});
