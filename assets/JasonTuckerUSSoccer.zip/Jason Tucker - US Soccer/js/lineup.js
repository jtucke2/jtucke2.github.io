/* Jason Tucker CMSY 168 */


$(function() {
	$( ".draggable" ).draggable({
	  containment: "parent"
	});
});

/* ------- GOALIE ------ */

function changeGoalie(drop_down) {
	var a = parseInt(drop_down.value);

	switch (a){
		case 1:
			goalie.innerHTML = "<img src=\"images\\players\\HOWARD.png\" class=\"roster\">";
			console.log("Goalie value selected = " + drop_down.value);
			break;
		case 2:
			goalie.innerHTML = "<img src=\"images\\players\\GUZAN.png\" class=\"roster\">";
			console.log("Goalie value selected = " + drop_down.value);
			break;
		case 3:
			goalie.innerHTML = "<img src=\"images\\players\\Hamid.jpg\" class=\"roster\">";
			console.log("Goalie value selected = " + drop_down.value);
	}
}



/* ------- RIGHT CENTERBACK ------ */

function changeRightCB(drop_down) {
	var b= parseInt(drop_down.value);

	switch (b){
		case 1:
			right_centerback.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("Right centerback value selected = " + drop_down.value);
			break;
		case 2:
			right_centerback.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("Right centerback value selected = " + drop_down.value);
			break;
		case 3:
			right_centerback.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("Right centerback value selected = " + drop_down.value);
      break;
      case 4:
  			right_centerback.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("Right centerback value selected = " + drop_down.value);
  			break;
  		case 5:
  			right_centerback.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("Right centerback value selected = " + drop_down.value);
  			break;
  		case 6:
  			right_centerback.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("Right centerback value selected = " + drop_down.value);
        break;
        case 7:
    			right_centerback.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("Right centerback value selected = " + drop_down.value);
    			break;
    		case 8:
    			right_centerback.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("Right centerback value selected = " + drop_down.value);
    			break;
    		case 9:
    			right_centerback.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("Right centerback value selected = " + drop_down.value);
				break;
			case 10:
      			right_centerback.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("Right centerback value selected = " + drop_down.value);
      			break;
      		case 11:
      			right_centerback.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("Right centerback value selected = " + drop_down.value);
      			break;
      		case 12:
      			right_centerback.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("Right centerback value selected = " + drop_down.value);
				break;
            case 13:
        			right_centerback.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("Right centerback value selected = " + drop_down.value);
        			break;
        		case 14:
        			right_centerback.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("Right centerback value selected = " + drop_down.value);
        			break;
        		case 15:
        			right_centerback.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("Right centerback value selected = " + drop_down.value);
              break;
              case 16:
          			right_centerback.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("Right centerback value selected = " + drop_down.value);
          			break;
          		case 17:
          			right_centerback.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("Right centerback value selected = " + drop_down.value);
          			break;
          		case 18:
          			right_centerback.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("Right centerback value selected = " + drop_down.value);
					break;
                case 19:
                  right_centerback.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("Right centerback value selected = " + drop_down.value);
                  break;
                case 20:
                  right_centerback.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("Right centerback value selected = " + drop_down.value);
                  break;
                case 21:
                  right_centerback.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("Right centerback value selected = " + drop_down.value);
                  break;
                  case 22:
                    right_centerback.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("Right centerback value selected = " + drop_down.value);
                    break;
                  case 23:
                    right_centerback.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("Right centerback value selected = " + drop_down.value);
                    break;
                  case 24:
                    right_centerback.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("Right centerback value selected = " + drop_down.value);
                    break;
                    case 25:
                      right_centerback.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("Right centerback value selected = " + drop_down.value);
                      break;
                    case 26:
                      right_centerback.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("Right centerback value selected = " + drop_down.value);
                      break;
                    case 27:
                      right_centerback.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("Right centerback value selected = " + drop_down.value);
					  break;
                      case 28:
                        right_centerback.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("Right centerback value selected = " + drop_down.value);
                        break;
                      case 29:
                        right_centerback.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("Right centerback value selected = " + drop_down.value);
                        break;
                      case 30:
                        right_centerback.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("Right centerback value selected = " + drop_down.value);
                        break;
                        case 31:
                          right_centerback.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("Right centerback value selected = " + drop_down.value);
                          break;

  }
}

/* ------- left CENTERBACK ------ */

function changeLeftCB(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			left_centerback.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("left centerback value selected = " + drop_down.value);
			break;
		case 2:
			left_centerback.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("left centerback value selected = " + drop_down.value);
			break;
		case 3:
			left_centerback.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("left centerback value selected = " + drop_down.value);
      break;
      case 4:
  			left_centerback.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("left centerback value selected = " + drop_down.value);
  			break;
  		case 5:
  			left_centerback.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("left centerback value selected = " + drop_down.value);
  			break;
  		case 6:
  			left_centerback.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("left centerback value selected = " + drop_down.value);
        break;
        case 7:
    			left_centerback.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("left centerback value selected = " + drop_down.value);
    			break;
    		case 8:
    			left_centerback.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("left centerback value selected = " + drop_down.value);
    			break;
    		case 9:
    			left_centerback.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("left centerback value selected = " + drop_down.value);
				break;
			case 10:
      			left_centerback.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("left centerback value selected = " + drop_down.value);
      			break;
      		case 11:
      			left_centerback.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("left centerback value selected = " + drop_down.value);
      			break;
      		case 12:
      			left_centerback.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("left centerback value selected = " + drop_down.value);
				break;
            case 13:
        			left_centerback.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("left centerback value selected = " + drop_down.value);
        			break;
        		case 14:
        			left_centerback.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("left centerback value selected = " + drop_down.value);
        			break;
        		case 15:
        			left_centerback.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("left centerback value selected = " + drop_down.value);
              break;
              case 16:
          			left_centerback.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("left centerback value selected = " + drop_down.value);
          			break;
          		case 17:
          			left_centerback.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("left centerback value selected = " + drop_down.value);
          			break;
          		case 18:
          			left_centerback.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("left centerback value selected = " + drop_down.value);
					break;
                case 19:
                  left_centerback.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("left centerback value selected = " + drop_down.value);
                  break;
                case 20:
                  left_centerback.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("left centerback value selected = " + drop_down.value);
                  break;
                case 21:
                  left_centerback.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("left centerback value selected = " + drop_down.value);
                  break;
                  case 22:
                    left_centerback.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("left centerback value selected = " + drop_down.value);
                    break;
                  case 23:
                    left_centerback.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("left centerback value selected = " + drop_down.value);
                    break;
                  case 24:
                    left_centerback.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("left centerback value selected = " + drop_down.value);
                    break;
                    case 25:
                      left_centerback.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("left centerback value selected = " + drop_down.value);
                      break;
                    case 26:
                      left_centerback.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("left centerback value selected = " + drop_down.value);
                      break;
                    case 27:
                      left_centerback.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("left centerback value selected = " + drop_down.value);
					  break;
                      case 28:
                        left_centerback.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("left centerback value selected = " + drop_down.value);
                        break;
                      case 29:
                        left_centerback.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("left centerback value selected = " + drop_down.value);
                        break;
                      case 30:
                        left_centerback.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("left centerback value selected = " + drop_down.value);
                        break;
                        case 31:
                          left_centerback.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("left centerback value selected = " + drop_down.value);
                          break;

  }
}

/* ------- right FULLBACK ------ */

function changeRightFB(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			right_fullback.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("Right fullback value selected = " + drop_down.value);
			break;
		case 2:
			right_fullback.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("Right fullback value selected = " + drop_down.value);
			break;
		case 3:
			right_fullback.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("Right fullback value selected = " + drop_down.value);
      break;
      case 4:
  			right_fullback.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("Right fullback value selected = " + drop_down.value);
  			break;
  		case 5:
  			right_fullback.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("Right fullback value selected = " + drop_down.value);
  			break;
  		case 6:
  			right_fullback.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("Right fullback value selected = " + drop_down.value);
        break;
        case 7:
    			right_fullback.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("Right fullback value selected = " + drop_down.value);
    			break;
    		case 8:
    			right_fullback.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("Right fullback value selected = " + drop_down.value);
    			break;
    		case 9:
    			right_fullback.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("Right fullback value selected = " + drop_down.value);
				break;
			case 10:
      			right_fullback.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("Right fullback value selected = " + drop_down.value);
      			break;
      		case 11:
      			right_fullback.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("Right fullback value selected = " + drop_down.value);
      			break;
      		case 12:
      			right_fullback.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("Right fullback value selected = " + drop_down.value);
				break;
            case 13:
        			right_fullback.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("Right fullback value selected = " + drop_down.value);
        			break;
        		case 14:
        			right_fullback.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("Right fullback value selected = " + drop_down.value);
        			break;
        		case 15:
        			right_fullback.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("Right fullback value selected = " + drop_down.value);
              break;
              case 16:
          			right_fullback.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("Right fullback value selected = " + drop_down.value);
          			break;
          		case 17:
          			right_fullback.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("Right fullback value selected = " + drop_down.value);
          			break;
          		case 18:
          			right_fullback.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("Right fullback value selected = " + drop_down.value);
					break;
                case 19:
                  right_fullback.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("Right fullback value selected = " + drop_down.value);
                  break;
                case 20:
                  right_fullback.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("Right fullback value selected = " + drop_down.value);
                  break;
                case 21:
                  right_fullback.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("Right fullback value selected = " + drop_down.value);
                  break;
                  case 22:
                    right_fullback.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("Right fullback value selected = " + drop_down.value);
                    break;
                  case 23:
                    right_fullback.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("Right fullback value selected = " + drop_down.value);
                    break;
                  case 24:
                    right_fullback.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("Right fullback value selected = " + drop_down.value);
                    break;
                    case 25:
                      right_fullback.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("Right fullback value selected = " + drop_down.value);
                      break;
                    case 26:
                      right_fullback.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("Right fullback value selected = " + drop_down.value);
                      break;
                    case 27:
                      right_fullback.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("Right fullback value selected = " + drop_down.value);
					  break;
                      case 28:
                        right_fullback.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("Right fullback value selected = " + drop_down.value);
                        break;
                      case 29:
                        right_fullback.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("Right fullback value selected = " + drop_down.value);
                        break;
                      case 30:
                        right_fullback.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("Right fullback value selected = " + drop_down.value);
                        break;
                        case 31:
                          right_fullback.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("Right fullback value selected = " + drop_down.value);
                          break;

  }
}

/* ------- left FULLBACK ------ */

function changeLeftFB(drop_down) {
	var z = parseInt(drop_down.value);

	switch (z){
		case 1:
			left_fullback.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("left fullback value selected = " + drop_down.value);
			break;
		case 2:
			left_fullback.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("left fullback value selected = " + drop_down.value);
			break;
		case 3:
			left_fullback.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("left fullback value selected = " + drop_down.value);
      break;
      case 4:
  			left_fullback.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("left fullback value selected = " + drop_down.value);
  			break;
  		case 5:
  			left_fullback.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("left fullback value selected = " + drop_down.value);
  			break;
  		case 6:
  			left_fullback.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("left fullback value selected = " + drop_down.value);
        break;
        case 7:
    			left_fullback.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("left fullback value selected = " + drop_down.value);
    			break;
    		case 8:
    			left_fullback.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("left fullback value selected = " + drop_down.value);
    			break;
    		case 9:
    			left_fullback.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("left fullback value selected = " + drop_down.value);
				break;
			case 10:
      			left_fullback.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("left fullback value selected = " + drop_down.value);
      			break;
      		case 11:
      			left_fullback.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("left fullback value selected = " + drop_down.value);
      			break;
      		case 12:
      			left_fullback.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("left fullback value selected = " + drop_down.value);
				break;
            case 13:
        			left_fullback.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("left fullback value selected = " + drop_down.value);
        			break;
        		case 14:
        			left_fullback.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("left fullback value selected = " + drop_down.value);
        			break;
        		case 15:
        			left_fullback.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("left fullback value selected = " + drop_down.value);
              break;
              case 16:
          			left_fullback.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("left fullback value selected = " + drop_down.value);
          			break;
          		case 17:
          			left_fullback.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("left fullback value selected = " + drop_down.value);
          			break;
          		case 18:
          			left_fullback.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("left fullback value selected = " + drop_down.value);
					break;
                case 19:
                  left_fullback.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("left fullback value selected = " + drop_down.value);
                  break;
                case 20:
                  left_fullback.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("left fullback value selected = " + drop_down.value);
                  break;
                case 21:
                  left_fullback.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("left fullback value selected = " + drop_down.value);
                  break;
                  case 22:
                    left_fullback.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("left fullback value selected = " + drop_down.value);
                    break;
                  case 23:
                    left_fullback.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("left fullback value selected = " + drop_down.value);
                    break;
                  case 24:
                    left_fullback.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("left fullback value selected = " + drop_down.value);
                    break;
                    case 25:
                      left_fullback.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("left fullback value selected = " + drop_down.value);
                      break;
                    case 26:
                      left_fullback.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("left fullback value selected = " + drop_down.value);
                      break;
                    case 27:
                      left_fullback.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("left fullback value selected = " + drop_down.value);
					  break;
                      case 28:
                        left_fullback.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("left fullback value selected = " + drop_down.value);
                        break;
                      case 29:
                        left_fullback.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("left fullback value selected = " + drop_down.value);
                        break;
                      case 30:
                        left_fullback.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("left fullback value selected = " + drop_down.value);
                        break;
                        case 31:
                          left_fullback.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("left fullback value selected = " + drop_down.value);
                          break;

  }
}

/* ------- right wing ------ */

function changeRightWing(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			right_wing.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("Right wing value selected = " + drop_down.value);
			break;
		case 2:
			right_wing.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("Right wing value selected = " + drop_down.value);
			break;
		case 3:
			right_wing.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("Right wing value selected = " + drop_down.value);
      break;
      case 4:
  			right_wing.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("Right wing value selected = " + drop_down.value);
  			break;
  		case 5:
  			right_wing.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("Right wing value selected = " + drop_down.value);
  			break;
  		case 6:
  			right_wing.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("Right wing value selected = " + drop_down.value);
        break;
        case 7:
    			right_wing.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("Right wing value selected = " + drop_down.value);
    			break;
    		case 8:
    			right_wing.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("Right wing value selected = " + drop_down.value);
    			break;
    		case 9:
    			right_wing.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("Right wing value selected = " + drop_down.value);
				break;
			case 10:
      			right_wing.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("Right wing value selected = " + drop_down.value);
      			break;
      		case 11:
      			right_wing.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("Right wing value selected = " + drop_down.value);
      			break;
      		case 12:
      			right_wing.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("Right wing value selected = " + drop_down.value);
				break;
            case 13:
        			right_wing.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("Right wing value selected = " + drop_down.value);
        			break;
        		case 14:
        			right_wing.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("Right wing value selected = " + drop_down.value);
        			break;
        		case 15:
        			right_wing.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("Right wing value selected = " + drop_down.value);
              break;
              case 16:
          			right_wing.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("Right wing value selected = " + drop_down.value);
          			break;
          		case 17:
          			right_wing.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("Right wing value selected = " + drop_down.value);
          			break;
          		case 18:
          			right_wing.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("Right wing value selected = " + drop_down.value);
					break;
                case 19:
                  right_wing.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("Right wing value selected = " + drop_down.value);
                  break;
                case 20:
                  right_wing.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("Right wing value selected = " + drop_down.value);
                  break;
                case 21:
                  right_wing.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("Right wing value selected = " + drop_down.value);
                  break;
                  case 22:
                    right_wing.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("Right wing value selected = " + drop_down.value);
                    break;
                  case 23:
                    right_wing.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("Right wing value selected = " + drop_down.value);
                    break;
                  case 24:
                    right_wing.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("Right wing value selected = " + drop_down.value);
                    break;
                    case 25:
                      right_wing.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("Right wing value selected = " + drop_down.value);
                      break;
                    case 26:
                      right_wing.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("Right wing value selected = " + drop_down.value);
                      break;
                    case 27:
                      right_wing.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("Right wing value selected = " + drop_down.value);
					  break;
                      case 28:
                        right_wing.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("Right wing value selected = " + drop_down.value);
                        break;
                      case 29:
                        right_wing.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("Right wing value selected = " + drop_down.value);
                        break;
                      case 30:
                        right_wing.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("Right wing value selected = " + drop_down.value);
                        break;
                        case 31:
                          right_wing.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("Right wing value selected = " + drop_down.value);
                          break;

  }
}
/* ------- right Midfielder ------ */

function changeRightMidfielder(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			right_midfielder.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("right midfielder value selected = " + drop_down.value);
			break;
		case 2:
			right_midfielder.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("right midfielder value selected = " + drop_down.value);
			break;
		case 3:
			right_midfielder.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("right midfielder value selected = " + drop_down.value);
      break;
      case 4:
  			right_midfielder.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("right midfielder value selected = " + drop_down.value);
  			break;
  		case 5:
  			right_midfielder.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("right midfielder value selected = " + drop_down.value);
  			break;
  		case 6:
  			right_midfielder.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("right midfielder value selected = " + drop_down.value);
        break;
        case 7:
    			right_midfielder.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("right midfielder value selected = " + drop_down.value);
    			break;
    		case 8:
    			right_midfielder.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("right midfielder value selected = " + drop_down.value);
    			break;
    		case 9:
    			right_midfielder.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("right midfielder value selected = " + drop_down.value);
				break;
			case 10:
      			right_midfielder.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("right midfielder value selected = " + drop_down.value);
      			break;
      		case 11:
      			right_midfielder.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("right midfielder value selected = " + drop_down.value);
      			break;
      		case 12:
      			right_midfielder.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("right midfielder value selected = " + drop_down.value);
				break;
            case 13:
        			right_midfielder.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("right midfielder value selected = " + drop_down.value);
        			break;
        		case 14:
        			right_midfielder.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("right midfielder value selected = " + drop_down.value);
        			break;
        		case 15:
        			right_midfielder.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("right midfielder value selected = " + drop_down.value);
              break;
              case 16:
          			right_midfielder.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("right midfielder value selected = " + drop_down.value);
          			break;
          		case 17:
          			right_midfielder.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("right midfielder value selected = " + drop_down.value);
          			break;
          		case 18:
          			right_midfielder.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("right midfielder value selected = " + drop_down.value);
					break;
                case 19:
                  right_midfielder.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("right midfielder value selected = " + drop_down.value);
                  break;
                case 20:
                  right_midfielder.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("right midfielder value selected = " + drop_down.value);
                  break;
                case 21:
                  right_midfielder.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("right midfielder value selected = " + drop_down.value);
                  break;
                  case 22:
                    right_midfielder.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("right midfielder value selected = " + drop_down.value);
                    break;
                  case 23:
                    right_midfielder.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("right midfielder value selected = " + drop_down.value);
                    break;
                  case 24:
                    right_midfielder.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("right midfielder value selected = " + drop_down.value);
                    break;
                    case 25:
                      right_midfielder.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("right midfielder value selected = " + drop_down.value);
                      break;
                    case 26:
                      right_midfielder.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("right midfielder value selected = " + drop_down.value);
                      break;
                    case 27:
                      right_midfielder.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("right midfielder value selected = " + drop_down.value);
					  break;
                      case 28:
                        right_midfielder.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("right midfielder value selected = " + drop_down.value);
                        break;
                      case 29:
                        right_midfielder.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("right midfielder value selected = " + drop_down.value);
                        break;
                      case 30:
                        right_midfielder.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("right midfielder value selected = " + drop_down.value);
                        break;
                        case 31:
                          right_midfielder.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("right midfielder value selected = " + drop_down.value);
                          break;

  }
}

/* ------- left Midfielder ------ */

function changeLeftMidfielder(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			left_midfielder.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("left midfielder value selected = " + drop_down.value);
			break;
		case 2:
			left_midfielder.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("left midfielder value selected = " + drop_down.value);
			break;
		case 3:
			left_midfielder.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("left midfielder value selected = " + drop_down.value);
      break;
      case 4:
  			left_midfielder.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("left midfielder value selected = " + drop_down.value);
  			break;
  		case 5:
  			left_midfielder.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("left midfielder value selected = " + drop_down.value);
  			break;
  		case 6:
  			left_midfielder.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("left midfielder value selected = " + drop_down.value);
        break;
        case 7:
    			left_midfielder.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("left midfielder value selected = " + drop_down.value);
    			break;
    		case 8:
    			left_midfielder.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("left midfielder value selected = " + drop_down.value);
    			break;
    		case 9:
    			left_midfielder.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("left midfielder value selected = " + drop_down.value);
				break;
			case 10:
      			left_midfielder.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("left midfielder value selected = " + drop_down.value);
      			break;
      		case 11:
      			left_midfielder.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("left midfielder value selected = " + drop_down.value);
      			break;
      		case 12:
      			left_midfielder.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("left midfielder value selected = " + drop_down.value);
				break;
            case 13:
        			left_midfielder.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("left midfielder value selected = " + drop_down.value);
        			break;
        		case 14:
        			left_midfielder.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("left midfielder value selected = " + drop_down.value);
        			break;
        		case 15:
        			left_midfielder.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("left midfielder value selected = " + drop_down.value);
              break;
              case 16:
          			left_midfielder.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("left midfielder value selected = " + drop_down.value);
          			break;
          		case 17:
          			left_midfielder.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("left midfielder value selected = " + drop_down.value);
          			break;
          		case 18:
          			left_midfielder.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("left midfielder value selected = " + drop_down.value);
					break;
                case 19:
                  left_midfielder.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("left midfielder value selected = " + drop_down.value);
                  break;
                case 20:
                  left_midfielder.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("left midfielder value selected = " + drop_down.value);
                  break;
                case 21:
                  left_midfielder.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("left midfielder value selected = " + drop_down.value);
                  break;
                  case 22:
                    left_midfielder.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("left midfielder value selected = " + drop_down.value);
                    break;
                  case 23:
                    left_midfielder.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("left midfielder value selected = " + drop_down.value);
                    break;
                  case 24:
                    left_midfielder.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("left midfielder value selected = " + drop_down.value);
                    break;
                    case 25:
                      left_midfielder.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("left midfielder value selected = " + drop_down.value);
                      break;
                    case 26:
                      left_midfielder.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("left midfielder value selected = " + drop_down.value);
                      break;
                    case 27:
                      left_midfielder.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("left midfielder value selected = " + drop_down.value);
					  break;
                      case 28:
                        left_midfielder.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("left midfielder value selected = " + drop_down.value);
                        break;
                      case 29:
                        left_midfielder.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("left midfielder value selected = " + drop_down.value);
                        break;
                      case 30:
                        left_midfielder.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("left midfielder value selected = " + drop_down.value);
                        break;
                        case 31:
                          left_midfielder.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("left midfielder value selected = " + drop_down.value);
                          break;

  }
}

/* ------- left wing ------ */

function changeLeftWing(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			left_wing.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("left wing value selected = " + drop_down.value);
			break;
		case 2:
			left_wing.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("left wing value selected = " + drop_down.value);
			break;
		case 3:
			left_wing.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("left wing value selected = " + drop_down.value);
      break;
      case 4:
  			left_wing.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("left wing value selected = " + drop_down.value);
  			break;
  		case 5:
  			left_wing.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("left wing value selected = " + drop_down.value);
  			break;
  		case 6:
  			left_wing.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("left wing value selected = " + drop_down.value);
        break;
        case 7:
    			left_wing.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("left wing value selected = " + drop_down.value);
    			break;
    		case 8:
    			left_wing.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("left wing value selected = " + drop_down.value);
    			break;
    		case 9:
    			left_wing.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("left wing value selected = " + drop_down.value);
				break;
			case 10:
      			left_wing.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("left wing value selected = " + drop_down.value);
      			break;
      		case 11:
      			left_wing.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("left wing value selected = " + drop_down.value);
      			break;
      		case 12:
      			left_wing.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("left wing value selected = " + drop_down.value);
				break;
            case 13:
        			left_wing.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("left wing value selected = " + drop_down.value);
        			break;
        		case 14:
        			left_wing.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("left wing value selected = " + drop_down.value);
        			break;
        		case 15:
        			left_wing.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("left wing value selected = " + drop_down.value);
              break;
              case 16:
          			left_wing.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("left wing value selected = " + drop_down.value);
          			break;
          		case 17:
          			left_wing.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("left wing value selected = " + drop_down.value);
          			break;
          		case 18:
          			left_wing.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("left wing value selected = " + drop_down.value);
					break;
                case 19:
                  left_wing.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("left wing value selected = " + drop_down.value);
                  break;
                case 20:
                  left_wing.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("left wing value selected = " + drop_down.value);
                  break;
                case 21:
                  left_wing.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("left wing value selected = " + drop_down.value);
                  break;
                  case 22:
                    left_wing.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("left wing value selected = " + drop_down.value);
                    break;
                  case 23:
                    left_wing.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("left wing value selected = " + drop_down.value);
                    break;
                  case 24:
                    left_wing.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("left wing value selected = " + drop_down.value);
                    break;
                    case 25:
                      left_wing.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("left wing value selected = " + drop_down.value);
                      break;
                    case 26:
                      left_wing.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("left wing value selected = " + drop_down.value);
                      break;
                    case 27:
                      left_wing.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("left wing value selected = " + drop_down.value);
					  break;
                      case 28:
                        left_wing.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("left wing value selected = " + drop_down.value);
                        break;
                      case 29:
                        left_wing.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("left wing value selected = " + drop_down.value);
                        break;
                      case 30:
                        left_wing.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("left wing value selected = " + drop_down.value);
                        break;
                        case 31:
                          left_wing.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("left wing value selected = " + drop_down.value);
                          break;

  }
}

/* ------- right forward ------ */

function changeRightForward(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			right_forward.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("Right forward value selected = " + drop_down.value);
			break;
		case 2:
			right_forward.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("Right forward value selected = " + drop_down.value);
			break;
		case 3:
			right_forward.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("Right forward value selected = " + drop_down.value);
      break;
      case 4:
  			right_forward.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("Right forward value selected = " + drop_down.value);
  			break;
  		case 5:
  			right_forward.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("Right forward value selected = " + drop_down.value);
  			break;
  		case 6:
  			right_forward.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("Right forward value selected = " + drop_down.value);
        break;
        case 7:
    			right_forward.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("Right forward value selected = " + drop_down.value);
    			break;
    		case 8:
    			right_forward.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("Right forward value selected = " + drop_down.value);
    			break;
    		case 9:
    			right_forward.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("Right forward value selected = " + drop_down.value);
				break;
			case 10:
      			right_forward.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("Right forward value selected = " + drop_down.value);
      			break;
      		case 11:
      			right_forward.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("Right forward value selected = " + drop_down.value);
      			break;
      		case 12:
      			right_forward.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("Right forward value selected = " + drop_down.value);
				break;
            case 13:
        			right_forward.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("Right forward value selected = " + drop_down.value);
        			break;
        		case 14:
        			right_forward.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("Right forward value selected = " + drop_down.value);
        			break;
        		case 15:
        			right_forward.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("Right forward value selected = " + drop_down.value);
              break;
              case 16:
          			right_forward.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("Right forward value selected = " + drop_down.value);
          			break;
          		case 17:
          			right_forward.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("Right forward value selected = " + drop_down.value);
          			break;
          		case 18:
          			right_forward.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("Right forward value selected = " + drop_down.value);
					break;
                case 19:
                  right_forward.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("Right forward value selected = " + drop_down.value);
                  break;
                case 20:
                  right_forward.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("Right forward value selected = " + drop_down.value);
                  break;
                case 21:
                  right_forward.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("Right forward value selected = " + drop_down.value);
                  break;
                  case 22:
                    right_forward.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("Right forward value selected = " + drop_down.value);
                    break;
                  case 23:
                    right_forward.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("Right forward value selected = " + drop_down.value);
                    break;
                  case 24:
                    right_forward.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("Right forward value selected = " + drop_down.value);
                    break;
                    case 25:
                      right_forward.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("Right forward value selected = " + drop_down.value);
                      break;
                    case 26:
                      right_forward.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("Right forward value selected = " + drop_down.value);
                      break;
                    case 27:
                      right_forward.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("Right forward value selected = " + drop_down.value);
					  break;
                      case 28:
                        right_forward.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("Right forward value selected = " + drop_down.value);
                        break;
                      case 29:
                        right_forward.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("Right forward value selected = " + drop_down.value);
                        break;
                      case 30:
                        right_forward.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("Right forward value selected = " + drop_down.value);
                        break;
                        case 31:
                          right_forward.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("Right forward value selected = " + drop_down.value);
                          break;

  }
}

/* ------- left forward ------ */

function changeLeftForward(drop_down) {
	var c= parseInt(drop_down.value);

	switch (c){
		case 1:
			left_forward.innerHTML = "<img src=\"images\\players\\Alfredo.JPG\" class=\"roster\">";
			console.log("left forward value selected = " + drop_down.value);
			break;
		case 2:
			left_forward.innerHTML = "<img src=\"images\\players\\ALTIDORE.png\" class=\"roster\">";
			console.log("left forward value selected = " + drop_down.value);
			break;
		case 3:
			left_forward.innerHTML = "<img src=\"images\\players\\ALVARADO.jpg\" class=\"roster\">";
			console.log("left forward value selected = " + drop_down.value);
      break;
      case 4:
  			left_forward.innerHTML = "<img src=\"images\\players\\Aron.JPG\" class=\"roster\">";
  			console.log("left forward value selected = " + drop_down.value);
  			break;
  		case 5:
  			left_forward.innerHTML = "<img src=\"images\\players\\BEASLEY.png\" class=\"roster\">";
  			console.log("left forward value selected = " + drop_down.value);
  			break;
  		case 6:
  			left_forward.innerHTML = "<img src=\"images\\players\\BECKERMAN.png\" class=\"roster\">";
  			console.log("left forward value selected = " + drop_down.value);
        break;
        case 7:
    			left_forward.innerHTML = "<img src=\"images\\players\\Bedoya.JPG\" class=\"roster\">";
    			console.log("left forward value selected = " + drop_down.value);
    			break;
    		case 8:
    			left_forward.innerHTML = "<img src=\"images\\players\\BESLER.jpg\" class=\"roster\">";
    			console.log("left forward value selected = " + drop_down.value);
    			break;
    		case 9:
    			left_forward.innerHTML = "<img src=\"images\\players\\BRADLEY.jpg\" class=\"roster\">";
    			console.log("left forward value selected = " + drop_down.value);
				break;
			case 10:
      			left_forward.innerHTML = "<img src=\"images\\players\\Brooks.JPG\" class=\"roster\">";
      			console.log("left forward value selected = " + drop_down.value);
      			break;
      		case 11:
      			left_forward.innerHTML = "<img src=\"images\\players\\CAMERON.png\" class=\"roster\">";
      			console.log("left forward value selected = " + drop_down.value);
      			break;
      		case 12:
      			left_forward.innerHTML = "<img src=\"images\\players\\Chandler.jpg\" class=\"roster\">";
        		console.log("left forward value selected = " + drop_down.value);
				break;
            case 13:
        			left_forward.innerHTML = "<img src=\"images\\players\\DEMPSEY.jpg\" class=\"roster\">";
        			console.log("left forward value selected = " + drop_down.value);
        			break;
        		case 14:
        			left_forward.innerHTML = "<img src=\"images\\players\\Evans.jpg\" class=\"roster\">";
        			console.log("left forward value selected = " + drop_down.value);
        			break;
        		case 15:
        			left_forward.innerHTML = "<img src=\"images\\players\\Fabian.jpg\" class=\"roster\">";
        			console.log("left forward value selected = " + drop_down.value);
              break;
              case 16:
          			left_forward.innerHTML = "<img src=\"images\\players\\GREEN.jpg\" class=\"roster\">";
          			console.log("left forward value selected = " + drop_down.value);
          			break;
          		case 17:
          			left_forward.innerHTML = "<img src=\"images\\players\\JONES.png\" class=\"roster\">";
          			console.log("left forward value selected = " + drop_down.value);
          			break;
          		case 18:
          			left_forward.innerHTML = "<img src=\"images\\players\\MIX.jpg\" class=\"roster\">";
          			console.log("left forward value selected = " + drop_down.value);
					break;
                case 19:
                  left_forward.innerHTML = "<img src=\"images\\players\\MORRIS.jpg\" class=\"roster\">";
                  console.log("left forward value selected = " + drop_down.value);
                  break;
                case 20:
                  left_forward.innerHTML = "<img src=\"images\\players\\NGUYEN.JPG\" class=\"roster\">";
                  console.log("left forward value selected = " + drop_down.value);
                  break;
                case 21:
                  left_forward.innerHTML = "<img src=\"images\\players\\Omar.jpg\" class=\"roster\">";
                  console.log("left forward value selected = " + drop_down.value);
                  break;
                  case 22:
                    left_forward.innerHTML = "<img src=\"images\\players\\OROZCO.jpg\" class=\"roster\">";
                    console.log("left forward value selected = " + drop_down.value);
                    break;
                  case 23:
                    left_forward.innerHTML = "<img src=\"images\\players\\Ream.JPG\" class=\"roster\">";
                    console.log("left forward value selected = " + drop_down.value);
                    break;
                  case 24:
                    left_forward.innerHTML = "<img src=\"images\\players\\SHEA.jpg\" class=\"roster\">";
                    console.log("left forward value selected = " + drop_down.value);
                    break;
                    case 25:
                      left_forward.innerHTML = "<img src=\"images\\players\\SPECTOR.jpg\" class=\"roster\">";
                      console.log("left forward value selected = " + drop_down.value);
                      break;
                    case 26:
                      left_forward.innerHTML = "<img src=\"images\\players\\Williams.JPG\" class=\"roster\">";
                      console.log("left forward value selected = " + drop_down.value);
                      break;
                    case 27:
                      left_forward.innerHTML = "<img src=\"images\\players\\WONDOLOWSKI.jpg\" class=\"roster\">";
                      console.log("left forward value selected = " + drop_down.value);
					  break;
                      case 28:
                        left_forward.innerHTML = "<img src=\"images\\players\\WOOD.png\" class=\"roster\">";
                        console.log("left forward value selected = " + drop_down.value);
                        break;
                      case 29:
                        left_forward.innerHTML = "<img src=\"images\\players\\YEDLIN.jpg\" class=\"roster\">";
                        console.log("left forward value selected = " + drop_down.value);
                        break;
                      case 30:
                        left_forward.innerHTML = "<img src=\"images\\players\\ZARDES.jpg\" class=\"roster\">";
                        console.log("left forward value selected = " + drop_down.value);
                        break;
                        case 31:
                          left_forward.innerHTML = "<img src=\"images\\players\\ZUSI.png\" class=\"roster\">";
                          console.log("left forward value selected = " + drop_down.value);
                          break;

  }
}


/* ~~~~~~~~~~~~~~~~ Contact Form ~~~~~~~~~~~~~~~ */

// draggable wrapper/form
$(function() {
	$( "#formWrapper" ).draggable({
	});
});

// Make form visible on "contact us" button click
$( "#contactButton" ).click(function() {
  $("#formWrapper").removeClass("invisible");
});

// Make form invisible on "cancel" button click
$( "#cancelButton" ).click(function() {
  $("#formWrapper").addClass("invisible");
});

// Submit Thank you alert
function formSubmission(form) {
  alert("Thank you for your comment, " + document.getElementById("name").value + ".");
  return true;
}
