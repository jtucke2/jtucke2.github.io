This website was created by Jason Tucker for Howard Community College's CMSY-168 Class, in the fall of 2015.

This website is for private and academic purposes only.

Please see the "sources.html" page for more information.